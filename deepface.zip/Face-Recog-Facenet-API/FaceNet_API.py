# Import all required libraries
import cv2
import matplotlib.pyplot as plt
import os
import numpy as np
from numpy.core.numeric import identity
from sklearn.preprocessing import Normalizer
from PIL import Image
from deepface.basemodels import VGGFace, Facenet
from flask import Flask, render_template, request, send_from_directory, url_for, redirect, jsonify, json
import codecs
import base64
from deepface.extendedmodels import Age, Gender, Race, Emotion
from deepface.commons import functions, realtime, distance as dst
from deepface import DeepFace

# Run Flask
app = Flask(__name__)

# Home page
@app.route('/')
def home():
    return render_template('verify_facenet.html')

#-----------------------------------------------------------------------------------------------------------------
# VERIFY FACENET

@app.route('/verify/facenet/distance', methods=['POST'])
def distance1():
    model = "Facenet"

    # upload 2 images
    img_upload = request.files['image']
    img2_upload = request.files['image2']

    # save 2 uploaded images to folder "upload"
    img = os.path.join("upload", img_upload.filename)
    print(img)
    img_upload.save(img)
    img2 = os.path.join("upload", img2_upload.filename)
    print(img2)
    img2_upload.save(img2)

    # verify the comparation of 2 images
    resp=DeepFace.verify(img1_path=img,img2_path=img2,model_name=model)

    # return result 
    return jsonify(resp)
#-----------------------------------------------------------------------------------------------------------------

if __name__ == '__main__':
    app.run(debug=True)

