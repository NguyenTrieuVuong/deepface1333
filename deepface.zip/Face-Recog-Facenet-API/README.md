# Face_Recognition_API
Face Recognition API using keras-facenet , flask and Python


![test1](https://user-images.githubusercontent.com/31994329/136490187-fbb917e7-404e-499a-81aa-f174b8825c77.jpg)

![test0](https://user-images.githubusercontent.com/31994329/136490989-1027d7fa-a6b4-496d-ad4e-7ed9d923198b.jpg)
